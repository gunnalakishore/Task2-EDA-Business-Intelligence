-- Task 2 Business Questions

-- 1. Total revenue
SELECT SUM(PurchaseAmount) AS Total_Revenue FROM sales_data;

-- 2. Average purchase value
SELECT AVG(PurchaseAmount) AS Average_Purchase FROM sales_data;

-- 3. City wise revenue
SELECT City, SUM(PurchaseAmount) AS Revenue
FROM sales_data
GROUP BY City
ORDER BY Revenue DESC;

-- 4. Customer count
SELECT COUNT(DISTINCT CustomerID) AS Customers FROM sales_data;

-- 5. Top customers
SELECT Name, SUM(PurchaseAmount) AS Total
FROM sales_data
GROUP BY Name
ORDER BY Total DESC;
